﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace appLista3
{
    public partial class Frmexercico1 : Form
    {
        public Frmexercico1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //pegar da tela 
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

            //Processamento (fazer contas!)
            soma = num1 + num3;

            //saida
            lblRSoma.Text = "soma igual a" + soma;
        }

       




        private void button2_Click(object sender, EventArgs e)
        {
            //Pegar da tela 
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media;
            //processamento
            media = (num1 + num2 + num3) / 3;
            //saida 
            lblRMedia.Text = "Media igual a" + media;



            
           

           
            

            
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float total, porcNum1, porcNum2, porcNum3;

            //processamento 
            total = num1 + num2 + num3;//100%
            porcNum1 = num1 / total;
            porcNum2 = num2 / total;
            porcNum3 = num3 / total;
            lblRPorcentagem.Text = "numero um e" + porcNum1 + "numero dois e: " + porcNum2 + "numero tres e:" + porcNum3;
        }

        private void Frmexercico1_Load(object sender, EventArgs e)
        {

        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
