﻿namespace appLista3
{
    partial class Frmexercico1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.num1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.lblRSoma = new System.Windows.Forms.Label();
            this.lblRMedia = new System.Windows.Forms.Label();
            this.lblRPorcentagem = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // num1
            // 
            this.num1.AutoSize = true;
            this.num1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.num1.ForeColor = System.Drawing.Color.Black;
            this.num1.Location = new System.Drawing.Point(127, 129);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(33, 13);
            this.num1.TabIndex = 0;
            this.num1.Text = "num1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(358, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "num2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(573, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "num3";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(100, 184);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(100, 20);
            this.txtNum1.TabIndex = 3;
            this.txtNum1.TextChanged += new System.EventHandler(this.txtNum1_TextChanged);
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(326, 184);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(100, 20);
            this.txtNum2.TabIndex = 4;
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(545, 184);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(100, 20);
            this.txtNum3.TabIndex = 5;
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(111, 266);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(75, 23);
            this.btnSoma.TabIndex = 6;
            this.btnSoma.Text = "soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(339, 266);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(75, 23);
            this.btnMedia.TabIndex = 7;
            this.btnMedia.Text = "media ";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.Location = new System.Drawing.Point(555, 266);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(79, 23);
            this.btnPorcentagem.TabIndex = 8;
            this.btnPorcentagem.Text = "porcentagem";
            this.btnPorcentagem.UseVisualStyleBackColor = true;
            this.btnPorcentagem.Click += new System.EventHandler(this.button3_Click);
            // 
            // lblRSoma
            // 
            this.lblRSoma.AutoSize = true;
            this.lblRSoma.Location = new System.Drawing.Point(127, 360);
            this.lblRSoma.Name = "lblRSoma";
            this.lblRSoma.Size = new System.Drawing.Size(86, 13);
            this.lblRSoma.TabIndex = 9;
            this.lblRSoma.Text = "Resultado soma ";
            // 
            // lblRMedia
            // 
            this.lblRMedia.AutoSize = true;
            this.lblRMedia.Location = new System.Drawing.Point(127, 386);
            this.lblRMedia.Name = "lblRMedia";
            this.lblRMedia.Size = new System.Drawing.Size(89, 13);
            this.lblRMedia.TabIndex = 10;
            this.lblRMedia.Text = "Resultado media ";
            // 
            // lblRPorcentagem
            // 
            this.lblRPorcentagem.AutoSize = true;
            this.lblRPorcentagem.Location = new System.Drawing.Point(127, 411);
            this.lblRPorcentagem.Name = "lblRPorcentagem";
            this.lblRPorcentagem.Size = new System.Drawing.Size(120, 13);
            this.lblRPorcentagem.TabIndex = 11;
            this.lblRPorcentagem.Text = "Resultado porcentagem";
            // 
            // Frmexercico1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblRPorcentagem);
            this.Controls.Add(this.lblRMedia);
            this.Controls.Add(this.lblRSoma);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.num1);
            this.Name = "Frmexercico1";
            this.Text = "Frmexercico1";
            this.Load += new System.EventHandler(this.Frmexercico1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label num1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Label lblRSoma;
        private System.Windows.Forms.Label lblRMedia;
        private System.Windows.Forms.Label lblRPorcentagem;
    }
}