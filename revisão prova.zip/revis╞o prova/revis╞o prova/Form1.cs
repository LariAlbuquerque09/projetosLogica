﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace revisão_prova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float valor1 = float.Parse(txtValor1.Text);
            float valor2 = float.Parse(txtValor2.Text);
            float valor3 = float.Parse(txtValor3.Text);

            //calcular
            valor1 = valor1 * 10 / 100 + valor1;
            valor2 = valor2 * 10 / 100 + valor2;
            valor3 = valor3 * 10 / 100 + valor3;
           //Resultado 
            lblResultado1.Text = "resultado é" + valor1;
            lblResultado2.Text = "resultado é" + valor2;
            lblResultado3.Text = "resultado é" + valor3;

        }
    }
}
