﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int varInteiro = int.Parse(txtInteiro.Text);
            float varDecimal = float.Parse(txtDecimal.Text);
            float resultado;

            //Soma;
            resultado = varInteiro + varDecimal + 3;
            MessageBox.Show("Subtracao: " + resultado);

            //Subtração;
            resultado = varInteiro - varDecimal;
            MessageBox.Show("subtracao: " + resultado);

            //multiplicação;
            resultado = varInteiro * varDecimal;
            MessageBox.Show("Multiplicacao: " + resultado);

            //Divisao 
            resultado = varInteiro / varDecimal;
            MessageBox.Show("Divisao: " + resultado); 







        }
    }
}
